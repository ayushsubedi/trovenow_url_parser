from trovenow_url_parser import application

if __name__ == '__main__':
    application.run(debug=True)
